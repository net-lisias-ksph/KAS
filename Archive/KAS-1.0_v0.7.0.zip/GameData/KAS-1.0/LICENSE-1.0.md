**Copyright Overview**

- Models and textures of port parts was created by Winn75, who retains the copyright.
- Models for TJ-1 & TJ-2 and textures was created by Shatten55, who retains the copyright.
- Source code and compiled binaries are released under Public Domain copyright by the author IgorZ.

**Copyright Overview**

- Models and textures of connector, ports, winches and magnet parts was created by Winn75, who retains the copyright.
- Models and textures of containers, bays, strut, pipe and pylon was created by zzz, who retains the copyright.
- Models for all remaining parts were created by KospY, who retains the copyrights.
- Config files, shaders, source code and compiled binaries are under copyright retained by KospY.
 

**YOU MAY :**

- Distribute your own parts using any part modules included in KAS.
- Distribute fixes in case of a compatibility problem with a new version of KSP (.dll only).
- Distribute video, screenshots or other media portraying unmodified versions of KAS in action.
- Distribute modified or unmodified versions of the KAS plugin source code on condition that a link to this license is - included.
- Modify KAS in any way for personal use.
- Request a waiver of any of these terms.
 

**All other rights are reserved.**

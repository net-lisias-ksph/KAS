# KAS - Kerbal Attachment System
#### Mod for [Kerbal Space Program](http://www.kerbalspaceprogram.com/)

---

KAS introduces new gameplay mechanics by adding winches, and EVA attachable struts/pipes. 
It gives some purpose to EVA and can be used for many things:

- Resource transfer
- Towing parts
- Base/vessel interconnections
- Vessel consolidation
- Cranes
- Airship anchoring
- Skycranes
- Elevators
- ...and more

---

Forum thread: [KAS](http://forum.kerbalspaceprogram.com/index.php?/topic/142594-12-kerbal-attachment-system-kas-v062/) 
